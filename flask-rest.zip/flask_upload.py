#-*- coding: utf-8 -*-
from flask import Flask, render_template, request
from werkzeug import secure_filename
from flask_cors import CORS
from datetime import datetime
import subprocess
import json
import operator
import threading

app = Flask(__name__)
cors = CORS(app, resources={
	r"/upload/*": {"origin": "*"},
	r"/fileUpload/*": {"origin": "*"},
})

#업로드 HTML 렌더링
@app.route('/upload')
def render_file():
	return render_template('upload.html')

#파일 업로드 처리
@app.route('/fileUpload', methods = ['GET', 'POST','OPTIONS'])

def upload_file():
	if request.method == 'POST':
		dt = datetime.now()
		f = request.files['file']
		input_file_format = f.filename.split('.')[-1]
		input_file_name = str(dt.microsecond) + '.' + input_file_format
		result_file_name = str(dt.microsecond)+'.txt'
		video_format = ['mp4','mov','MP4','MOV']
		image_format = ['png','jpg','jpeg','PNG','JPG','JPEG']
		object_class = ['person','bicycle','car','motorbike','aeroplane','bus','train','truck','boat','traffic light','fire hydrant','stop sign','parking meter','bench','bird','cat','dog','horse','sheep','cow','elephant','bear','zebra','giraffe','backpack','umbrella','handbag','tie','suitcase','frisbee','skis','snowboard','sports ball','kite','baseball bat','baseball glove','skateboard','surfboard','tennis racket','bottle','wine glass','cup','fork','knife','spoon','bowl','banana','apple','sandwich','orange','broccoli','carrot','hot dog','pizza','donut','cake','chair','sofa','pottedplant','bed','diningtable','toilet','tvmonitor','laptop','mouse','remote','keyboard','cell phone','microwave','oven','toaster','sink','refrigerator','book','clock','vase','scissors','teddy bear','hair drier','toothbrush']
		emotion_class = ['Angry','Disgust','Fear','Happy','Sad','Surprise','Neutral']
		object_dic = {}
		emotion_dic = {}
		#저장할 경로 + 파일명
		f.save('/home/testyongth/flask-rest/save_data/'+ secure_filename(input_file_name))

		#동영상
		if input_file_format in video_format:
			
			result_obj_v = subprocess.check_output(['../darknet/darknet','detector','demo','../darknet/cfg/coco.data',\
				'../darknet/cfg/yolov3.cfg','../darknet/yolov3.weights',\
				'save_data/'+input_file_name, '-ext_output', '>', 'result_data/'+result_file_name])
			str_rov = result_obj_v.decode('utf-8')

			f_v = open('result_data/'+result_file_name,'w')
			f_v.write(str_rov)
			f_v.close()
			f_v = open('result_data/'+result_file_name,'r')
			lines = f_v.readlines()

			find_person = False

			for line in lines:
				if ':' in line :
					words = line.split(':')[0]
					if words in object_class:
						# 딕셔너리 저장
						if words in object_dic :
							object_dic[words] += 1
						else :
							object_dic[words] = 1
							
			f_v.close()
			
			# 사람을 찾으면 emotion detect
			if 'person' in object_dic.keys():
				result_emo_v = subprocess.check_output(['../darknet/darknet','detector','demo','../darknet/cfg/emotion.data',\
					'../darknet/cfg/yolo-emotion.cfg','../darknet/yolov3_emotion.weights',\
					'save_data/'+input_file_name, '-ext_output', '>', 'result_data/'+result_file_name])
				str_rev = result_emo_v.decode('utf-8')

				f_v = open('result_data/'+result_file_name+'_e','w')
				f_v.write(str_rev)
				f_v.close()
				f_v = open('result_data/'+result_file_name+'_e','r')
				lines = f_v.readlines()
				for line in lines:
					if ':' in line :
						words = line.split(':')[0]
						# 딕셔너리 저장
						if words in emotion_class:
							if words in emotion_dic :
								emotion_dic[words] += 1
							else :
								emotion_dic[words] = 1
				find_person = False
				f_v.close()

			object_list = []
			for word in object_dic:
				temp_dic = {}
				temp_dic['name']=word
				temp_dic['count']=object_dic[word]
				object_list.append(temp_dic)

			emotion_list = []
			for word in emotion_dic:
				temp_dic = {}
				temp_dic['name']=word
				temp_dic['count']=emotion_dic[word]
				emotion_list.append(temp_dic)

			# dict sorting
			for base in range(len(object_list)-1):
				for comp in range(base+1,len(object_list)):
					if object_list[base]['count'] < object_list[comp]['count']:
						temp = object_list[comp]
						object_list[comp] = object_list[base]
						object_list[base] = temp
						
			for base in range(len(emotion_list)-1):
				for comp in range(base+1,len(emotion_list)):
					if emotion_list[base]['count'] < emotion_list[comp]['count']:
						temp = emotion_list[comp]
						emotion_list[comp] = emotion_list[base]
						emotion_list[base] = temp

			res_dic = {}
			res_dic['object'] = object_list
			res_dic['emotion'] = emotion_list
			json_dic = json.dumps(res_dic)

			# 파일 삭제
			subprocess.check_output(['rm','./save_data/'+input_file_name])

			return json_dic

		#사진
		elif input_file_format in image_format:
			
			result_obj_i = subprocess.check_output(['../darknet/darknet','detector','test','../darknet/cfg/coco.data',\
				'../darknet/cfg/yolov3.cfg','../darknet/yolov3.weights',\
				'save_data/'+input_file_name, '-ext_output', '>', 'result_data/'+result_file_name,'-dont_show'])
			str_roi = result_obj_i.decode('utf-8')
			f_i = open('result_data/'+result_file_name,'w')
			f_i.write(str_roi)
			f_i.close()
			f_i = open('result_data/'+result_file_name,'r')
			lines = f_i.readlines()
			for line in lines:
				if ':' in line :
					words = line.split(':')[0]
					if words in object_class:
						if words in object_dic :
							object_dic[words] += 1
						else :
							object_dic[words] = 1
			f_i.close()
			
			# 사람을 찾으면 emotion detect
			if 'person' in object_dic.keys():
				result_emo_i = subprocess.check_output(['../darknet/darknet','detector','test','../darknet/cfg/emotion.data',\
					'../darknet/cfg/yolo-emotion.cfg','../darknet/yolov3_emotion.weights',\
					'save_data/'+input_file_name, '-ext_output', '>', 'result_data/'+result_file_name,'-dont_show'])
				str_rei = result_emo_i.decode('utf-8')
				f_i = open('result_data/'+result_file_name+'_e','w')
				f_i.write(str_rei)
				f_i.close()
				f_i = open('result_data/'+result_file_name+'_e','r')
				lines = f_i.readlines()
                
				for line in lines:
					if ':' in line :
						words = line.split(':')[0]
						# 딕셔너리 저장
						if words in emotion_class:
							if words in emotion_dic :
								emotion_dic[words] += 1
							else :
								emotion_dic[words] = 1
				find_person = False
				f_i.close()

			object_list = []
			for word in object_dic:
				temp_dic = {}
				temp_dic['name']=word
				temp_dic['count']=object_dic[word]
				object_list.append(temp_dic)
			
			emotion_list = []
			for word in emotion_dic:
				temp_dic = {}
				temp_dic['name']=word
				temp_dic['count']=emotion_dic[word]
				emotion_list.append(temp_dic)
			# dict sorting
			for base in range(len(object_list)-1):
				for comp in range(base+1,len(object_list)):
					if object_list[base]['count'] < object_list[comp]['count']:
						temp = object_list[comp]
						object_list[comp] = object_list[base]
						object_list[base] = temp
						
			for base in range(len(emotion_list)-1):
				for comp in range(base+1,len(emotion_list)):
					if emotion_list[base]['count'] < emotion_list[comp]['count']:
						temp = emotion_list[comp]
						emotion_list[comp] = emotion_list[base]
						emotion_list[base] = temp

			res_dic = {}
			res_dic['object'] = object_list
			res_dic['emotion'] = emotion_list
			json_dic = json.dumps(res_dic)

			# 파일 삭제
			subprocess.check_output(['rm','./save_data/'+input_file_name])

			return json_dic
        
		# 파일 삭제
		subprocess.check_output(['rm','./save_data/'+input_file_name])

		res_dic = {}
		res_dic['object'] = ''
		res_dic['emotion'] = ''
		json_dic = json.dumps(res_dic)
		return json_dic
    
	if request.method == 'OPTIONS':
		return 'success'

if __name__ == '__main__':
    #서버 실행
   app.run(host='0.0.0.0',port = 8888, debug = True)
